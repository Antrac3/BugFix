// File removed - OfflineIndicator was causing performance issues with excessive database checks
